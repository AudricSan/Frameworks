<?php
class carDAO extends MasterDAO{

    // Change the values according to your hosting.
    private $username = "root";     //The login to connect to the DB
    private $password = "";         //The password to connect to the DB
    private $host = "localhost";    //The name of the server where my DB is located
    private $dbname = "poo review";    //The name of the DB you want to attack.

    //DON'T TOUCH IT, LITTLE PRICK
    private $options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');

    public function __construct () {
        $this->table = "voiture"; // The table to attack => OU CAN EDIT THIS LINE

        $this->connection = new PDO("mysql:host={$this->host};dbname={$this->dbname};charset=utf8", $this->username, $this->password, $this->options);;
        $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function createObject ($result) {
        if(empty($result['Voiture_ID'])){
            $result['Voiture_ID'] = 0;
        }

        return new Car(
            $result['Voiture_ID'],
            $result['Voiture_Chassis'],
            $result['Voiture_Puissance'],
            $result['Voiture_Couleur']
        );
    }

    public function insert ($data){
        if(empty($data['Voiture_Chassis']) && empty($data['Voiture_Puissance']) && empty($data['Voiture_Couleur'])){
            return false;
        }
            $newCar = $this->createObject($data);
            // var_dump($newCar);
            // exit;

            try {
                $statement = $this->connection->prepare("INSERT INTO `voiture` (`Voiture_Chassis`, `Voiture_Puissance`, `Voiture_Couleur`) VALUES (?, ?, ?)");
                $statement->execute([$newCar->serial, $newCar->power, $newCar->color]);
    
                $newCar->ID = $this->connection->lastInsertID();
                return $newCar;
            } catch (PDOException $e) {
                var_dump($e);
            }
    }

    public function update ($id, $data){
        if(empty($id) && empty($data['Voiture_Chassis']) && empty($data['Voiture_Puissance']) && empty($data['Voiture_Couleur'])){
            return false;
        }

        $check = $this->fetch("Voiture_ID", $id);
        if (empty($check)){
            return false;
        }

        try {
            $statement = $this->connection->prepare("UPDATE voiture SET Voiture_Chassis = ? , Voiture_Puissance = ?, Voiture_Couleur = ? WHERE Voiture_ID = ?");
            $statement->execute([$data["Voiture_Chassis"], $data["Voiture_Puissance"], $data["Voiture_Couleur"], $id]);
            
            $update = $this->fetch("Voiture_ID", $id);
            return $update;
        } catch (PDOException $e) {
            var_dump($e);
        }
    }
}