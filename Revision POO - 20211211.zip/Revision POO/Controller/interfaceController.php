<?php
interface interfaceController {     
    public function index ();
    public function show ($id);
    public function create ();
    public function insert($data);
}
?>